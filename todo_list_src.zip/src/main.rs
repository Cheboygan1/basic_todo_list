use std::io;
use std::fs;
use serde::{Serialize, Deserialize};

#[derive(Debug, Serialize, Deserialize)]
// TodoItem that stores the title and description, id, and whether or not its been completed
pub struct TodoItem {
    pub id: String,
    pub title: String,
    pub description: String,
    pub completed: bool,
}

#[derive(Debug, Serialize, Deserialize)]
// TodoList will be the main struct with implimentation, stores TodoItems in a vector
pub struct TodoList {
    pub items: Vec<TodoItem>,
}

// This body stores the main functionality for program
impl TodoList {

    // create a new List
    pub fn new() -> Self {
        TodoList { items: Vec::new() }
    }

    // Runs user through adding a title and description
    // Auto creates an id, and defaults to uncompleted
    pub fn add_item(&mut self) {
        // this variable creates a number based on the length of the List vector
        let mut id_int = self.items.len() as u32 + 1;

        // check if the id already exists, if so, adds 1 to id_int
        for item in &self.items {
            if id_int == item.id.parse::<u32>().expect("Parse Error!") {
                id_int += 1;
            }
        }

        // change id_int into String and give it to id
        // This is because id field in TodoItem is a String to make some things simpler
        let id = id_int.to_string();
        
        // Let user know what id will be used
        println!("The id for this item will be: {id}\n
            Add a title for the item:");

        // create title with io::stdin    
        let mut title = String::new();
        
        io::stdin().read_line(&mut title)
            .expect("Input not recognized...");
        
        // create description with io::stdin
        println!("\nAdd a short description for this item:");

        let mut description = String::new();
        
        io::stdin().read_line(&mut description)
            .expect("Input not recognized...");

        // push new item into List vector
        self.items.push(TodoItem { id, title, description, completed: false });
    }

    // Main function of program
    pub fn list(&mut self) {
        
        // basic instructions for the user, prints once per call
        println!("// Type 'complete x' where 'x' is item id to update record to completed.
        // Type 'delete x' where 'x' is the id to delete record.
        // Type 'add' to add a new item to the list :)
        // Type 'clear' to remove all items from the list
        // At any point type 'exit' to return to main menu");

        // loops to allow for multiple inputs
        loop {
            // Prints message and lists out items in list
            println!("\t\nHere is your list of To Dos:");
            for item in &self.items { // iterates through TodoList vector
                println!("\n{}: [{}] {}\n\t{}", item.id, 
                        if item.completed {"x"} else {" "},
                        item.title,
                        item.description);
            }

            // create user input for further commands
            let mut selection = String::new();

            io::stdin().read_line(&mut selection)
                .expect("Input not recognized");

            // if else statements run through users input 
            if selection.trim().to_lowercase() == "exit" { // type exit to return to main menu
                return;
            }
            else if selection.to_lowercase().starts_with("add") { // add runs add_item() function
                self.add_item();
            }
            else if selection.to_lowercase().starts_with("complete") { // if starts with complete
                // iterates through todo list to find matching id's
                for item in &mut self.items {
                    // if selection string past the length of "complete " equals item id
                    if item.id == selection["complete ".len()..].trim() {
                        item.completed = true // change field to completed
                    }
                }
            }
            else if selection.to_lowercase().starts_with("clear") { // if starts with clear
                self.items.clear(); // remove all items from the list   
            }
            else if selection.to_lowercase().starts_with("delete") { // if starts with delete
                // store value of id specified after "delete " 
                let id_select = selection["delete ".len()..].trim();
                
                // items vector retains all items except for id_select, gets rid of entry
                self.items.retain(|item| item.id != id_select);
            }

        } // end loop
    }

    // saves data from list object to filename given as a parameter else where
    pub fn save_to_file(&self, filename: &str) -> std::io::Result<()> {
        // serialize data to send to .json file
        let serialized = serde_json::to_string_pretty(&self)?;
        fs::write(filename, serialized)?;
        Ok(())
    }
    // loads data from list object to filename given as a parameter else where
    pub fn load_from_file(filename: &str) -> std::io::Result<Self> {
        let data = fs::read_to_string(filename)?;
        // deserialize data back to Rust struct
        let todo_list: TodoList = serde_json::from_str(&data)?;
        Ok(todo_list)
    }
    // make sure the user doesn't accidentally quit without saving
    pub fn exit_fn(&self) {
        println!("Would you like to save any changes made to the list(y/n)?");

        let mut choice = String::new();

        io::stdin().read_line(&mut choice)
            .expect("Failed to read input...");

        if choice.to_lowercase().starts_with("y") {
            
            match &self.save_to_file("todo_list.json") {
                Ok(_) => { println!("Todo list saved succesfully!"); },
                Err(err) => { println!("Failed to save todo list: {err}"); }
            }
        }
        else {
            return;
        }

    }
}

fn main() {
    let mut list = match TodoList::load_from_file("todo_list.json") {
        Ok(list) => list,
        Err(_) => {
            println!("No existing Todo List found. Starting a new one!");
            TodoList::new()
        }
    };
    
    loop {
        println!("\n\n\t\tTo Do List Menu\n\n");
    
        println!("
            1) List\n
            2) Save List\n
            3) Exit
            ");
        
        let mut selection = String::new();
    
        io::stdin().read_line(&mut selection)
            .expect("Input not understood.");
    
        match selection.trim() {
            "1" => {
                println!("You selected: 'List");
                list.list();
               
            },
            "2" => {
                println!("You selected: Save List");
                match list.save_to_file("todo_list.json") {
                    Ok(_) => { println!("Todo list saved succesfully!"); },
                    Err(err) => { println!("Failed to save todo list: {err}"); }
                }
            },
            "3" => {
                list.exit_fn();
                println!("Exiting program. Goodbye...");
                break;
            },
            _ => {
                println!("Input not recognized...");
            },
        };
    }
}
